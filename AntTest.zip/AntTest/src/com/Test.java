package com;

public class Test {
	public static void main(String args)
	{
		System.out.print("Ant test");
	}
}
